# JPEG-Compression
Information Theory project : Implementation of JPEG Image Compression
